function globalSystem=Assembly(globalSystem,meshStruct)
% globalSystem=ASSEMBLY(globalSystem,meshStruct)
% Assemble global stiffness matrix K for the TRUSS2D code. 
% last edit: 5 September 2017 H. Ritz

% unpack necessary inputs
nnpe=meshStruct.nnpe;
numDOF=meshStruct.numDOF;
numEls=meshStruct.numEls;
gatherMat=meshStruct.gatherMat;
%theta_con = meshStruct.theta_con;
multiCon = meshStruct.multiCon;
epsilon = meshStruct.epsilon;

% We will first create a local stiffness matrix "ke" (call the function 
% TrussElem.m) and then put "ke" into our global stiffness matrix K

% The following nested for loop may seem intimidating, but all we need to
% do is to locate the local and global row & column index.
numNodes=meshStruct.numNodes; %% total number of nodes
elCon=meshStruct.elCon;       %% Connectivity array
% K=zeros(numNodes*numDOF);     %% Initializing the global stiffness matrix
% for e=1:numEls % for each element
%     ke = TrussElem(e,meshStruct); % make the local stiffness matrix
%     for i = 1 : nnpe
%         for ii = 1 : numDOF
%             Lrw = numDOF*(i-1)+ii; % local row index
%             Grw = numDOF*(elCon(e,i)-1)+ii; % global row index
%             for j = 1 : nnpe
%                 for jj = 1 : numDOF
%                     Lcl = numDOF*(j-1)+jj; % local column index
%                     Gcl = numDOF*(elCon(e,j)-1)+jj; % global column index                   
%                     % Assemble local stiffness matrix into the global
%                     % stiffness matrix here
%                     K(Grw,Gcl) = K(Grw,Gcl) + ke(Lrw,Lcl);                    
%                 end
%             end
%         end
%     end
% end

%return
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Here is another version of the same code. You can take advantage of the
% gatherMat array which has already been defined to simplify some of the
% loops. Fill in the missing code to assemble ke into K2 which should be
% identical to K. 

K=zeros(numNodes*numDOF);
for e=1:numEls % for each element
    ke = TrussElem(e,meshStruct); % make the local stiffness matrix
    for lclROW = 1 : (nnpe*numDOF)
        glbROW = gatherMat(e,lclROW); %% Added line
        for lclCOL = 1 : (nnpe*numDOF)
            glbCOL = gatherMat(e,lclCOL); %% Added line
            % Assemble local stiffness matrix into the global
            % stiffness matrix here
            K(glbROW,glbCOL) = K(glbROW,glbCOL)+ke(lclROW,lclCOL); %% Added line
        end
    end

end

q = globalSystem.q;

%% To construct the matrix "C" which contains constraint information
theta_con = multiCon(:,2);
c_elem =[-sin(theta_con) cos(theta_con)];
C = zeros(size(q,1),numNodes*numDOF);
for ii = 1:1:size(q,1)
      position_loc_con =(multiCon(ii,1) -1)*numDOF;
      C(ii,position_loc_con+1) = C(ii,position_loc_con+1) + c_elem(ii,1);
      C(ii,position_loc_con+2) = C(ii,position_loc_con+2) + c_elem(ii,2);
end

%% Updating K
 K = K + epsilon*(C'*C);
%%
globalSystem.C=C;


% Package variables into the output structs
globalSystem.K=K;

% Compare results from different methods.
%display(['The maximum difference between K and K2 is ', num2str(max(max(abs(K-K2))))]);



