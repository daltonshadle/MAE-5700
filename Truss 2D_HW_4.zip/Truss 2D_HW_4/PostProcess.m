function globalSystem = PostProcess(globalSystem,meshStruct,boundStruct)
% globalSystem = POSTPROCESS(globalSystem,meshStruct,boundStruct)
% Calculate strains, stresses, and internal forces for each element in the
% TRUSS2D problem. Plot the intial and deformed shapes of the truss. Print
% relevant problem data and results.
% Note: this code is "vectorized" meaning the results are calculated for
% all elements simultaneously. Take a few minutes to understand how the
% code works.
% last edit: 30 July 2015 H. Ritz

% unpack necessary input
nnpe = meshStruct.nnpe;
nCoords  = meshStruct.nCoords; 
numEls    =meshStruct.numEls;
elCon     =meshStruct.elCon;
gatherMat =meshStruct.gatherMat;
nCoords   =meshStruct.nCoords;
elYM      =meshStruct.elYM;
elArea    =meshStruct.elArea;
multiCon = meshStruct.multiCon;
d         =globalSystem.d';

% initialize output vectors
strain=zeros(numEls,1);
stress=zeros(numEls,1);
force =zeros(numEls,1);

gn1 = elCon(:,1);  % Extract the global node numbers
gn2 = elCon(:,2);  % for all elements

% get nodal coordinates
x1=nCoords(gn1,1); y1=nCoords(gn1,2);
x2=nCoords(gn2,1); y2=nCoords(gn2,2);

L=sqrt((x2-x1).^2+(y2-y1).^2); % L = initial length of the elements
c=(x2-x1)./L; % cosine of the angle of the elements with the X axis
s=(y2-y1)./L; % cosine of the angle of the elements with the Y axis
operator=[-c -s c s];
strain=sum(operator.*d(gatherMat),2)./L;   % element strain
stress=elYM.*strain;  % element stress
force=elArea.*stress; % internal element force

% Package variables into the output structs
globalSystem.strain=strain;
globalSystem.stress=stress;
globalSystem.force =force;

%% Capturing the reaction forces at inclined surface
Multi_pos_loc = multiCon(:,1);
for jj = 1:1:length(Multi_pos_loc)
    node_loc = [];
    for ii = 1:1:nnpe
     node_loc = [node_loc;find(Multi_pos_loc(jj,1) == elCon(:,ii))]
    end
% calculating slope of the elements wrt to global x-axis
    for pp = 1:1:size(node_loc,1)
    globalNodes_MC = elCon(node_loc(pp),:);
    point1 = nCoords(globalNodes_MC(1),:);
    point2 = nCoords(globalNodes_MC(2),:);
 %   slope(pp,jj)= atan((point2(2) - point1(2))./(point2(1) - point1(1)));
   slope(pp,jj)= atan2((point2(2) - point1(2)),(point2(1) - point1(1)));
    reactionVec_contrib_x(pp,jj) =  globalSystem.force(node_loc(pp))*cos(slope(pp,jj));
    reactionVec_contrib_y(pp,jj) = globalSystem.force(node_loc(pp))*sin(slope(pp,jj));
%    reactionVec_contrib_x1(pp,jj) =  abs(globalSystem.force(node_loc(pp)))*cos(slope1(pp,jj));
 %   reactionVec_contrib_y1(pp,jj) = abs(globalSystem.force(node_loc(pp)))*sin(slope1(pp,jj));
    end
end
rad2deg(slope)
% slope1
 reactionVec_contrib_x
 reactionVec_contrib_y
% reactionVec_contrib_x1
% reactionVec_contrib_y1
% finding the reaction forces at multi-point constrained nodes
for jj = 1:1:length(Multi_pos_loc)
    reactionVec_inclined(:,jj) = [sum(reactionVec_contrib_x(:,jj)); sum(reactionVec_contrib_y(:,jj))];
 %   reactionVec_inclined1(:,jj) = [sum(reactionVec_contrib_x1(:,jj)); sum(reactionVec_contrib_y1(:,jj))];
end
%%
globalSystem.Multi_pos_loc = Multi_pos_loc;
globalSystem.reactionVec_inclined = reactionVec_inclined;

% print out the results of the problem, including plots
PresentResults(globalSystem,meshStruct,boundStruct); 
% schematic of which elements are in tenson or compression
PlotTensionCompression(globalSystem,meshStruct); 